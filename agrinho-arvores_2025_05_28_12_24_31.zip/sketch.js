function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let personX = 0; // Posição inicial da pessoa
let personY = 500; // Posição vertical da pessoa (fixa)
let personWidth = 30;
let personHeight = 60;
let stepSize = 3; // Velocidade da pessoa andando

let crops = []; // Array para armazenar as plantas
let pollution = 100; // Nível de poluição inicial
let airQuality = 0; // Qualidade do ar
let temp = 30; // Temperatura inicial

function setup() {
  createCanvas(800, 600);
  frameRate(30);
  
  // Adicionar áreas de cultivo (inicialmente sem plantas)
  for (let i = 0; i < 5; i++) {
    let cropX = random(200, 600);  // Posições aleatórias para as áreas de cultivo
    let cropY = random(400, 550);
    crops.push({ x: cropX, y: cropY, size: 0 }); // Tamanho inicial 0 (não plantado)
  }
}

function draw() {
  background(200, 220, 255); // Cor do céu
  
  // Desenhar a cidade (prédios)
  fill(150, 150, 150);
  for (let i = 0; i < 5; i++) {
    rect(100 + i * 150, 350, 40, 150); // Representação simples de prédios
  }
  
  // Desenhar as áreas de cultivo (hortas)
  fill(34, 139, 34); // Cor das plantas
  for (let i = 0; i < crops.length; i++) {
    ellipse(crops[i].x, crops[i].y, crops[i].size, crops[i].size); // Desenhando a planta
    if (crops[i].size < 60) { // Se a planta ainda não cresceu completamente
      crops[i].size += 0.2; // Crescimento gradual da planta
    }
  }
  
  // Desenhar a pessoa andando
  fill(255, 0, 0); // Cor da pessoa (vermelho)
  rect(personX, personY - personHeight, personWidth, personHeight); // Corpo da pessoa
  
  // Atualizando a posição da pessoa (movimento para a direita)
  personX += stepSize;

  // Se a pessoa atingir o final da tela, reiniciar a posição
  if (personX > width) {
    personX = -personWidth;
  }
  
  // Efeito ambiental conforme a pessoa anda
  // Se a pessoa passar por áreas de cultivo, ela faz as plantas crescerem mais rápido
  for (let i = 0; i < crops.length; i++) {
    if (personX + personWidth > crops[i].x - 20 && personX < crops[i].x + 20) {
      if (crops[i].size < 60) {
        crops[i].size += 0.5; // A planta cresce mais rápido ao passar pela pessoa
      }
    }
  }

  // Simulação de poluição e qualidade do ar
  pollution -= crops.length * 0.2; // Menos poluição conforme as plantas crescem
  pollution = constrain(pollution, 0, 100);
  
  // Melhora da qualidade do ar com mais plantas
  airQuality = map(crops.length, 0, 10, 0, 100);
  
  // Mudança de temperatura conforme o número de árvores
  temp = map(crops.length, 0, 10, 30, 25);

  // Mostrar informações de poluição, qualidade do ar e temperatura
  fill(0);
  textSize(16);
  text('Poluição: ' + nf(pollution, 0, 2), 10, 30);
  text('Qualidade do Ar: ' + nf(airQuality, 0, 2), 10, 60);
  text('Temperatura: ' + nf(temp, 0, 1) + '°C', 10, 90);
}

